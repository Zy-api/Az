# 高级下载网站 + 后台管理系统

这是一个带前台和后台的 Node.js 全栈网站。

## 功能

- 高级深色视觉前台
- 邮箱注册和邮箱登录后台
- 密码加密保存
- 后台编辑前台页面内容
- 后台修改品牌名、标题、按钮、介绍、功能卡片、下载区文案、页脚和主题色
- 后台上传文件
- 后台删除文件
- 前台真实下载后台上传的文件
- SQLite 本地数据库，启动后自动创建

## 本地运行

```bash
npm install
npm start
```

打开：

- 前台：`http://localhost:3000`
- 后台：`http://localhost:3000/admin`

第一次进入后台时，点击“注册后台账号”，用邮箱注册即可。

## 环境变量

复制 `.env.example` 为 `.env`：

```bash
cp .env.example .env
```

建议修改：

```bash
SESSION_SECRET=一段很长很随机的字符串
ADMIN_OPEN_REGISTRATION=true
```

如果上线后不希望别人继续注册后台账号，改成：

```bash
ADMIN_OPEN_REGISTRATION=false
```

注意：如果数据库里还没有任何后台账号，系统仍允许创建第一个账号。

## 文件位置

- 数据库：`data/site.sqlite`
- 上传文件：`public/files`
- 页面模板：`views`
- 样式文件：`public/styles.css`
- 服务端：`server.js`

## GitHub 上传

不要把 GitHub 密码或 token 写进代码、README、命令历史或公开聊天。推荐先在 GitHub 创建一个空仓库，然后在本项目目录执行：

```bash
git init
git add .
git commit -m "Initial website"
git branch -M main
git remote add origin https://github.com/你的用户名/你的仓库名.git
git push -u origin main
```

推送时请使用 GitHub 官方登录、GitHub CLI、SSH Key，或在终端交互式输入 token。不要把 token 拼到远程地址里。

## 上线提醒

- 上线前务必设置强 `SESSION_SECRET`
- 注册好第一个后台账号后，建议设置 `ADMIN_OPEN_REGISTRATION=false`
- 如果部署在 Render、Railway、VPS 等平台，确保 `data` 和 `public/files` 有持久化存储，否则重启后上传文件可能丢失
