require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const multer = require("multer");
const { nanoid } = require("nanoid");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const FILE_DIR = path.join(ROOT, "public", "files");
const DB_PATH = path.join(DATA_DIR, "site.sqlite");

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(FILE_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS site_content (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    logo_text TEXT NOT NULL,
    nav_label TEXT NOT NULL,
    badge TEXT NOT NULL,
    hero_title TEXT NOT NULL,
    hero_subtitle TEXT NOT NULL,
    primary_button TEXT NOT NULL,
    secondary_button TEXT NOT NULL,
    about_title TEXT NOT NULL,
    about_text TEXT NOT NULL,
    feature_1_title TEXT NOT NULL,
    feature_1_text TEXT NOT NULL,
    feature_2_title TEXT NOT NULL,
    feature_2_text TEXT NOT NULL,
    feature_3_title TEXT NOT NULL,
    feature_3_text TEXT NOT NULL,
    downloads_title TEXT NOT NULL,
    downloads_text TEXT NOT NULL,
    footer_text TEXT NOT NULL,
    accent_color TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    original_name TEXT NOT NULL,
    size INTEGER NOT NULL,
    mime_type TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const defaultContent = {
  logo_text: "LUXE FILE",
  nav_label: "精选资源",
  badge: "Premium Digital Downloads",
  hero_title: "高级资源下载中心",
  hero_subtitle: "用一个精致、可信、速度很快的网站展示你的资源。访客可以在前台查看文件并真实下载，你可以在后台随时更新页面文案和文件列表。",
  primary_button: "查看可下载文件",
  secondary_button: "了解网站亮点",
  about_title: "为高价值文件而设计",
  about_text: "前台采用深色玻璃质感、柔和光效和高级排版，适合展示软件、资料包、模板、课程附件或内部资源。后台提供内容编辑和文件管理能力，不需要改代码就能维护网站。",
  feature_1_title: "后台内容可编辑",
  feature_1_text: "首页标题、介绍、按钮、功能卡片、下载区文案、品牌名和主题色都可以在后台修改。",
  feature_2_title: "真实文件下载",
  feature_2_text: "后台上传的文件会保存到服务器，前台用户点击下载按钮即可获取真实文件。",
  feature_3_title: "邮箱账号系统",
  feature_3_text: "后台支持邮箱注册和登录，密码会加密保存，并使用会话保持登录状态。",
  downloads_title: "可下载文件",
  downloads_text: "这里展示后台上传的资源。你可以添加、删除文件，也可以编辑文件的展示标题和说明。",
  footer_text: "© 2026 LUXE FILE. Built for premium downloads.",
  accent_color: "#d6a85c"
};

const existingContent = db.prepare("SELECT id FROM site_content WHERE id = 1").get();
if (!existingContent) {
  db.prepare(`
    INSERT INTO site_content (
      id, logo_text, nav_label, badge, hero_title, hero_subtitle,
      primary_button, secondary_button, about_title, about_text,
      feature_1_title, feature_1_text, feature_2_title, feature_2_text,
      feature_3_title, feature_3_text, downloads_title, downloads_text,
      footer_text, accent_color
    ) VALUES (
      1, @logo_text, @nav_label, @badge, @hero_title, @hero_subtitle,
      @primary_button, @secondary_button, @about_title, @about_text,
      @feature_1_title, @feature_1_text, @feature_2_title, @feature_2_text,
      @feature_3_title, @feature_3_text, @downloads_title, @downloads_text,
      @footer_text, @accent_color
    )
  `).run(defaultContent);
}

app.set("view engine", "ejs");
app.set("views", path.join(ROOT, "views"));

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));
app.use(express.static(path.join(ROOT, "public")));
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, FILE_DIR),
    filename: (req, file, cb) => {
      const safeExt = path.extname(file.originalname).replace(/[^a-zA-Z0-9.]/g, "");
      cb(null, `${Date.now()}-${nanoid(10)}${safeExt}`);
    }
  }),
  limits: {
    fileSize: 1024 * 1024 * 500
  }
});

function getContent() {
  return db.prepare("SELECT * FROM site_content WHERE id = 1").get();
}

function getFiles() {
  return db.prepare("SELECT * FROM files ORDER BY created_at DESC").all();
}

function getUserCount() {
  return db.prepare("SELECT COUNT(*) AS count FROM users").get().count;
}

function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.redirect("/admin/login");
  }
  next();
}

function renderAdmin(res, view, data = {}) {
  res.render(view, {
    ...data,
    flash: data.flash || null
  });
}

function cleanString(value, fallback = "") {
  return String(value || "").trim() || fallback;
}

app.get("/", (req, res) => {
  res.render("index", {
    content: getContent(),
    files: getFiles()
  });
});

app.get("/download/:id", (req, res) => {
  const file = db.prepare("SELECT * FROM files WHERE id = ?").get(req.params.id);
  if (!file) return res.status(404).send("文件不存在");

  const target = path.join(FILE_DIR, file.stored_name);
  if (!fs.existsSync(target)) return res.status(404).send("源文件已丢失");

  res.download(target, file.original_name);
});

app.get("/admin", requireAuth, (req, res) => {
  renderAdmin(res, "admin", {
    user: db.prepare("SELECT email FROM users WHERE id = ?").get(req.session.userId),
    content: getContent(),
    files: getFiles(),
    userCount: getUserCount()
  });
});

app.get("/admin/login", (req, res) => {
  renderAdmin(res, "login", {
    canRegister: process.env.ADMIN_OPEN_REGISTRATION !== "false" || getUserCount() === 0
  });
});

app.post("/admin/login", async (req, res) => {
  const email = cleanString(req.body.email).toLowerCase();
  const password = cleanString(req.body.password);
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return renderAdmin(res, "login", {
      flash: "邮箱或密码不正确",
      canRegister: process.env.ADMIN_OPEN_REGISTRATION !== "false" || getUserCount() === 0
    });
  }

  req.session.userId = user.id;
  res.redirect("/admin");
});

app.get("/admin/register", (req, res) => {
  const canRegister = process.env.ADMIN_OPEN_REGISTRATION !== "false" || getUserCount() === 0;
  if (!canRegister) return res.redirect("/admin/login");
  renderAdmin(res, "register");
});

app.post("/admin/register", async (req, res) => {
  const canRegister = process.env.ADMIN_OPEN_REGISTRATION !== "false" || getUserCount() === 0;
  if (!canRegister) return res.redirect("/admin/login");

  const email = cleanString(req.body.email).toLowerCase();
  const password = cleanString(req.body.password);

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return renderAdmin(res, "register", { flash: "请输入正确的邮箱地址" });
  }

  if (password.length < 8) {
    return renderAdmin(res, "register", { flash: "密码至少需要 8 位" });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)").run(email, passwordHash);
    req.session.userId = result.lastInsertRowid;
    res.redirect("/admin");
  } catch (error) {
    renderAdmin(res, "register", { flash: "这个邮箱已经注册过" });
  }
});

app.post("/admin/content", requireAuth, (req, res) => {
  const fields = [
    "logo_text", "nav_label", "badge", "hero_title", "hero_subtitle",
    "primary_button", "secondary_button", "about_title", "about_text",
    "feature_1_title", "feature_1_text", "feature_2_title", "feature_2_text",
    "feature_3_title", "feature_3_text", "downloads_title", "downloads_text",
    "footer_text", "accent_color"
  ];

  const values = {};
  fields.forEach((field) => {
    values[field] = cleanString(req.body[field], defaultContent[field] || "");
  });

  if (!/^#[0-9a-fA-F]{6}$/.test(values.accent_color)) {
    values.accent_color = defaultContent.accent_color;
  }

  db.prepare(`
    UPDATE site_content SET
      logo_text = @logo_text,
      nav_label = @nav_label,
      badge = @badge,
      hero_title = @hero_title,
      hero_subtitle = @hero_subtitle,
      primary_button = @primary_button,
      secondary_button = @secondary_button,
      about_title = @about_title,
      about_text = @about_text,
      feature_1_title = @feature_1_title,
      feature_1_text = @feature_1_text,
      feature_2_title = @feature_2_title,
      feature_2_text = @feature_2_text,
      feature_3_title = @feature_3_title,
      feature_3_text = @feature_3_text,
      downloads_title = @downloads_title,
      downloads_text = @downloads_text,
      footer_text = @footer_text,
      accent_color = @accent_color,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = 1
  `).run(values);

  res.redirect("/admin#content");
});

app.post("/admin/files", requireAuth, upload.single("file"), (req, res) => {
  if (!req.file) return res.redirect("/admin#files");

  db.prepare(`
    INSERT INTO files (id, title, description, stored_name, original_name, size, mime_type)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    nanoid(14),
    cleanString(req.body.title, req.file.originalname),
    cleanString(req.body.description, "这个文件可以从前台直接下载。"),
    req.file.filename,
    req.file.originalname,
    req.file.size,
    req.file.mimetype || "application/octet-stream"
  );

  res.redirect("/admin#files");
});

app.post("/admin/files/:id/delete", requireAuth, (req, res) => {
  const file = db.prepare("SELECT * FROM files WHERE id = ?").get(req.params.id);
  if (file) {
    const target = path.join(FILE_DIR, file.stored_name);
    if (fs.existsSync(target)) fs.unlinkSync(target);
    db.prepare("DELETE FROM files WHERE id = ?").run(req.params.id);
  }

  res.redirect("/admin#files");
});

app.post("/admin/logout", requireAuth, (req, res) => {
  req.session.destroy(() => res.redirect("/admin/login"));
});

app.use((req, res) => {
  res.status(404).render("404", { content: getContent() });
});

app.listen(PORT, () => {
  console.log(`网站已启动：http://localhost:${PORT}`);
});
